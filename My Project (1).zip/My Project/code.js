//the buttons the homescreen bottom
onEvent("matchbutton", "click", function( ) {
  setScreen("matchpage");
  playSound("assets/category_app/app_ice_button_click_3.mp3", false);
console.log("matchbutton clicked!");
});
onEvent("homebutton", "click", function( ) {
  setScreen("homescreen");
playSound("assets/category_app/app_ice_button_click_3.mp3", false);
console.log("homebutton clicked!");
});
onEvent("profilebutton", "click", function( ) {
  setScreen("profile");
console.log("profilebutton clicked!");
  playSound("assets/category_app/app_ice_button_click_3.mp3", false);
});
onEvent("settingsbutton", "click", function( ) {
  setScreen("settingspage");
  playSound("assets/category_app/app_ice_button_click_3.mp3", false);
console.log("settingsbutton clicked!");
});
onEvent("label4", "click", function( ) {
  setScreen("homescreen");
  playSound("assets/category_app/app_ice_button_click_3.mp3", false);
console.log("label4 clicked!");
});
onEvent("label5", "click", function( ) {
   setScreen("homescreen");
   playSound("assets/category_app/app_ice_button_click_3.mp3", false);
console.log("label5 clicked!");
});
onEvent("label6", "click", function( ) {
   setScreen("homescreen");
   playSound("assets/category_app/app_ice_button_click_3.mp3", false);
console.log("label6 clicked!");
});
//STOP

//go back buttons
onEvent("goback1", "click", function( ) {
  setScreen("homescreen");
  playSound("assets/category_app/app_ice_button_click_3.mp3", false);
console.log("goback1 clicked!");
});
onEvent("goback2", "click", function( ) {
  setScreen("homescreen");
  playSound("assets/category_app/app_ice_button_click_3.mp3", false);
console.log("goback2 clicked!");
});
onEvent("goback3", "click", function( ) {
  setScreen("homescreen");
  playSound("assets/category_app/app_ice_button_click_3.mp3", false);
console.log("goback3 clicked!");
});
//STOP

//shop buttons
onEvent("buyflowers", "click", function( ) {
  playSound("assets/category_pop/chirp_ding_bing_bong_1.mp3", false);
console.log("buyflowers clicked!");
});
onEvent("buyteddy", "click", function( ) {
playSound("assets/category_bell/bells_win.mp3", false);
console.log("buyteddy clicked!");
});
onEvent("buyring", "click", function( ) {
playSound("assets/category_human/character_yury_i_love_you.mp3", false);
console.log("buyring clicked!");
});
onEvent("buycake", "click", function( ) {
playSound("assets/category_music/birthday_kazoo_positive_game_cue_3.mp3", false);
console.log("buycake clicked!");
});
//STOP
//code end 

